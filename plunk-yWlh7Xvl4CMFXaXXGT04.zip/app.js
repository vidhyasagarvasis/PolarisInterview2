var app = angular.module("myApp", ['ngRoute']);

app.config(function($routeProvider) {
  $routeProvider
    .when("/", {
      templateUrl: "main.html",
    })
    .when("/viewUserCards", {
      templateUrl: "viewUserCards.html",
      controller: "viewUserCards"
    })
    .when("/viewTodos", {
      templateUrl: "viewTodos.html",
      controller: "viewUserCards"
    })
    .when("/createNewTodo", {
      templateUrl: "createNewTodo.html",
      controller: "viewTodos"
    });
});



app.controller('viewUserCards', function($scope, $http) {
  $http.get("https://jsonplaceholder.typicode.com/users").then(function(response) {
    $scope.myData = response.data;
  });
});

app.controller('viewTodos', function($scope, $http) {
  $http.post("https://jsonplaceholder.typicode.com/todos?userId=XXX").then(function(data,response) {
    $scope.myData = response.data;
  });
});


$scope.checkAll = function() {
  if (!$scope.selectedAll) {
    $scope.selectedAll = true;
  } else {
    $scope.selectedAll = false;
  }
  angular.forEach($scope.myData, function(x) {
    x.myData = $scope.selectedAll;
  });
}

$scope.addNew = function(x) {
  $scope.myData.push({
    'id': "",
    'name': "",
    'email': "",
    'mobile': "",
    'website': "",
  });
};

$scope.remove = function() {
  var newDataList = [];
  $scope.selectedAll = false;
  angular.forEach($scope.myData, function(selected) {
    if (!selected.selected) {
      newDataList.push(selected);
    }
  });
  $scope.myData = newDataList;
};